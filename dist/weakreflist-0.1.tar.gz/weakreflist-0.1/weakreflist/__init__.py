# -*- coding: utf8 -*-
__all__ = ['weakreflist']
