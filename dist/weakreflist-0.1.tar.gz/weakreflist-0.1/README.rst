===========
weakreflist
===========
---------------------------------------------------------------------
A WeakList class for storing objects using weak references in a list.
---------------------------------------------------------------------

*usage*
 see tests